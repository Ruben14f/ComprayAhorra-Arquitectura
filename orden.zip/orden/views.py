from django.shortcuts import render
from .utils import funcionOrden
from cart.funciones import funcionCarrito
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from cart.models import Cart,CartProduct
from orden.models import Orden


def orden(request):
    cart = funcionCarrito(request)
    orden = funcionOrden(cart, request)
        
    return render(request, 'orden/orden.html',{
        'cart' : cart
    })


@login_required
def procesar_pago(request):
    if request.method == "POST":
        # Obtener datos del formulario (nombre, tarjeta, etc.)
        card_name = request.POST.get('card_name')
        card_number = request.POST.get('card_number')
        expiry_date = request.POST.get('expiry_date')
        cvv = request.POST.get('cvv')

        # Simular un pago exitoso
        pago_exitoso = True  # Aquí implementarías tu lógica de API de pago

        if pago_exitoso:
            try:
                # Obtener el carrito del usuario
                carrito = Cart.objects.get(user=request.user)

                # Crear un registro de la orden (opcional)
                Orden.objects.create(
                    user=request.user,
                    total=carrito.total
                )

                # Vaciar el carrito
                carrito.products.clear()

                # Redirigir a la página de confirmación
                return render(request, 'orden/compra_exitosa.html', {
                    'mensaje': 'Pago realizado con éxito.'
                })
            except Cart.DoesNotExist:
                # Si el carrito no existe, redirigir al carrito vacío
                return redirect('cart')

        # Si el pago falla, regresar al formulario con un mensaje de error
        return render(request, 'orden/orden.html', {
            'error': 'Hubo un problema con tu pago. Inténtalo de nuevo.'
        })

    # Redirigir al carrito si se accede sin POST
    return redirect('cart')
