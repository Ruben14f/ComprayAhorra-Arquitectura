from django.contrib import admin
from .models import Orden

# Register your models here.
admin.site.register(Orden)
